import json

import numpy as np
import matplotlib.pyplot as plt

from typing import List, Tuple
from matplotlib.axes import Axes


class GeometricMap:
    """With boundary and obstacle coordinates.
    
    Attributes:
        boundary: A PolygonObstacle object.
        obstacle_dict: A dictionary of PolygonObstacle objects.
    """

    def __init__(self, boundary_coords: List[tuple], obstacle_list: List[List[tuple]], inflation_margin:float=None):
        """The init should not be used directly. Use from_json() instead.

        Arguments:
            boundary_coords: A list of tuples, each tuple is a pair of coordinates.
            obstacle_list: A list of lists of tuples, each tuple is a pair of coordinates.
            inflation_margin: The margin to inflate the obstacles by.
        """
        boundary_coords, obstacle_list = self.__input_validation(boundary_coords, obstacle_list)

        self._inflation_margin = inflation_margin
        self.boundary:PolygonObstacle = None
        self.obstacle_dict:dict[int, PolygonObstacle] = {}

        self.register_boundary(boundary_coords)
        for obs in obstacle_list:
            self.register_obstacle(obs)

    def __input_validation(self, boundary_coords, obstacle_list):
        if not isinstance(boundary_coords, list):
            raise TypeError('A map boundary must be a list of tuples.')
        if not isinstance(obstacle_list, list):
            raise TypeError('A map obstacle list must be a list of lists of tuples.')
        if len(boundary_coords[0])!=2 or len(obstacle_list[0][0])!=2:
            raise TypeError('All coordinates must be 2-dimension.')
        return boundary_coords, obstacle_list

    def __call__(self, inflated:bool=True) -> Tuple[List[tuple], List[List[tuple]]]:
        """Return the boundary and obstacle coordinates."""
        boundary_coords = self.boundary(inflated=inflated)
        obstacle_list = [obs(inflated=True) for obs in self.obstacle_dict.values()]
        return boundary_coords, obstacle_list
    
    @classmethod
    def from_json(cls, json_path: str, inflation_margin:float=None):
        with open(json_path, 'r') as jf:
            data = json.load(jf)
        boundary_coords = data['boundary_coords']
        obstacle_list = data['obstacle_list']
        return cls(boundary_coords, obstacle_list, inflation_margin)
    
    def register_obstacle(self, vertices: List[tuple], id_:int=None, name:str=None) -> None:
        """Register an obstacle to the map."""
        obstacle = PolygonObstacle.from_raw(vertices, id_=id_, name=name)
        self.obstacle_dict[obstacle.id_] = obstacle
        if self._inflation_margin is not None:
            obstacle.inflate(self._inflation_margin)

    def register_boundary(self, vertices: List[tuple]) -> None:
        self.boundary = PolygonObstacle.from_raw(vertices, name="boundary")
        if self._inflation_margin is not None:
            self.boundary.inflate(-self._inflation_margin)
    
    def set_inflation_margin(self, inflation_margin:float) -> None:
        self._inflation_margin = inflation_margin
        self.boundary.inflate(-inflation_margin)
        for obs in self.obstacle_dict.values():
            obs.inflate(inflation_margin)


    def get_boundary_scope(self, inflated:bool=False) -> Tuple[float, float, float, float]:
        """Get the boundary scope."""
        boundary_coords = self.boundary(inflated=inflated)
        x_min = min([x[0] for x in boundary_coords])
        x_max = max([x[0] for x in boundary_coords])
        y_min = min([x[1] for x in boundary_coords])
        y_max = max([x[1] for x in boundary_coords])
        return x_min, x_max, y_min, y_max

    def get_occupancy_map(self, rescale:int=100, inflated=False) -> np.ndarray:
        """
        Args:
            rescale: The resolution of the occupancy map.
        Returns:
            A numpy array of shape (height, width, 3).
        """
        if not isinstance(rescale, int):
            raise TypeError(f'Rescale factor must be int, got {type(rescale)}.')
        assert(0<rescale<2000),(f'Rescale value {rescale} is abnormal.')
        
        boundary_np = np.array(self.boundary(inflated=False))
        width  = max(boundary_np[:,0]) - min(boundary_np[:,0])
        height = max(boundary_np[:,1]) - min(boundary_np[:,1])

        fig, ax = plt.subplots(figsize=(width, height), dpi=rescale)
        ax.set_aspect('equal')
        ax.axis('off')
        ax.plot(np.array(self.boundary(inflated=inflated))[:,0], 
                np.array(self.boundary(inflated=inflated))[:,1], 'w-')
        for obs in self.obstacle_dict.values():
            x = np.array(obs(inflated=inflated))[:,0]
            y = np.array(obs(inflated=inflated))[:,1]
            plt.fill(x, y, color='k')
        fig.tight_layout(pad=0)
        fig.canvas.draw()
        occupancy_map = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
        occupancy_map = occupancy_map.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        plt.close()
        return occupancy_map

    def plot(self, ax: Axes, inflated:bool=True, original_plot_args:dict={'c':'k'}, inflated_plot_args:dict={'c':'r'}):
        if inflated:
            self.boundary.plot(ax, inflated=True, fill=False, **inflated_plot_args)
            for obs in self.obstacle_dict.values():
                obs.plot(ax, inflated=True, fill=True, alpha=0.5, **inflated_plot_args)
        self.boundary.plot(ax, inflated=False, fill=False, **original_plot_args)
        for obs in self.obstacle_dict.values():
            obs.plot(ax, inflated=False, fill=True, **original_plot_args)


if __name__ == '__main__':
    boundary = [(0,0), (10,0), (10,10), (0,10)]
    obstacle_list = [[(1,1), (2,1), (2,2), (1,2)], [(3,3), (4,3), (4,4), (3,4)]]
    map = GeometricMap(boundary, obstacle_list)
    map.get_occupancy_map()
    fig, ax = plt.subplots()
    map.plot(ax, inflated=False)
    plt.show()