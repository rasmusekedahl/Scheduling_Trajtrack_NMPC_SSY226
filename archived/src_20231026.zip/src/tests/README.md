To run a unit test with verbose (at the root of the project):
```
python -m unittest src.tests.test_<test_name> -v
```

To list all the tests:
```
python src/tests/list_all_test.py
```